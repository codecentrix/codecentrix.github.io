﻿//////////////////////////////////////////////////////////////
// (c)2012 CodeCentrix Software. All rights reserved.
//
// This C# application demonstrates how to instantiate Twebst
// core object with a redistributable license key.
//////////////////////////////////////////////////////////////

using System;
using System.Text;
using TwebstLib;
using System.Runtime.InteropServices;


namespace Redist
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                ICore core = CreateCoreObject(REDIST_LICENSE_KEY);
                System.Console.WriteLine("Core object created!");
            }
            catch (COMException ex)
            {
                System.Console.WriteLine(ex.Message);
            }
        }


		// Create Twebst Core object using IClassFactory2 interface.
		private static ICore CreateCoreObject(String licenseKey)
		{
			// Get the IClassFactory2 for twebst library.
			const int      INPROC_SERVER = 1;
			Guid           twebstGuid    = new Guid("173BCDCD-0D75-4CF0-949D-5A07D17384C0");
			Guid           factory2Guid  = typeof(IClassFactory2).GUID;
			IClassFactory2 classFactory  = CoGetClassObject(ref twebstGuid, INPROC_SERVER, 0, ref factory2Guid);

			// Create a Core object using IClassFactory2 object using the license string.
			Guid   coreGuid   = typeof(ICore).GUID;
			Object core;

			classFactory.CreateInstanceLic(null, null, ref coreGuid, licenseKey, out core);
			return (ICore)core;
		}


		[DllImport("Ole32.dll", ExactSpelling = true, PreserveSig = false)]
		private static extern IClassFactory2 CoGetClassObject([In] ref Guid clsid, int dwContext, int serverInfo, [In] ref Guid refiid);


        /////////////////////////////////////////////////////////////////////////////////////////////
        private static readonly String REDIST_LICENSE_KEY = "LICENSE KEY FROM PURCHASE ORDER";
    }



    // IClassFactory2 COM interface definition.
	[ComImport(), Guid("B196B28F-BAB4-101A-B69C-00AA00341D07"), InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IClassFactory2
	{
		void CreateInstance   ([In, MarshalAs(UnmanagedType.Interface)] object unused,
		                       [In] ref Guid refiid,
		                       [Out, MarshalAs(UnmanagedType.LPArray)] object[] ppunk);
		void LockServer       (int fLock);
		void GetLicInfo       ([Out] IntPtr licInfo);
		void RequestLicKey    ([In,  MarshalAs(UnmanagedType.U4)]        int        dwReserved,
		                       [Out, MarshalAs(UnmanagedType.LPArray)]   string[]   pBstrKey);
		void CreateInstanceLic([In,  MarshalAs(UnmanagedType.Interface)] object     pUnkOuter,
		                       [In,  MarshalAs(UnmanagedType.Interface)] object     pUnkReserved,
		                       [In]                                      ref Guid   riid,
		                       [In,  MarshalAs(UnmanagedType.BStr)]      string     bstrKey,
		                       [Out, MarshalAs(UnmanagedType.Interface)] out object ppVal);
	}
}
