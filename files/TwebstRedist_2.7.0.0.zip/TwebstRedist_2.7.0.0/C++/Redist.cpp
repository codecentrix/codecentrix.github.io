///////////////////////////////////////////////////////////////
// (c)2012 CodeCentrix Software. All rights reserved.
//
// This C++ application demonstrates how to instantiate Twebst
// core object with a redistributable license key.
///////////////////////////////////////////////////////////////
#include "stdafx.h"
#import "progid:Twebst.Core"
//using namespace TwebstLib;


int _tmain(int argc, _TCHAR* argv[])
{
	::CoInitialize(NULL);

	try
	{
		CComQIPtr<IClassFactory2> spFactory;
		HRESULT hRes = ::CoGetClassObject(__uuidof(TwebstLib::core), CLSCTX_INPROC_SERVER, NULL, IID_IClassFactory2 , (LPVOID*)&spFactory);

		if (FAILED(hRes))
		{
			// Failed to get factory object.
			throw _com_error(hRes);
		}

		TwebstLib::ICorePtr pCore;
		hRes = spFactory->CreateInstanceLic(NULL, NULL, __uuidof(TwebstLib::ICore), CComBSTR("LICENSE KEY FROM PURCHASE ORDER"), (LPVOID*)&pCore);

		if (FAILED(hRes))
		{
			// Failed to create licensed Core object.
			throw _com_error(hRes);
		}

		std::cout << "Core object created!\n";
	}
	catch (_com_error comErr)
	{
		std::cout << "Error, hRes=" << std::hex << comErr.Error() << "\n";
	}

	::CoUninitialize();
	return 0;
}
