﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' (c)2012 CodeCentrix Software. All rights reserved.
'
' This VB.Net application demonstrates how to instantiate Twebst
' core object with a redistributable license key.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Imports TwebstLib
Imports System.Runtime.InteropServices


Public Class Redist
    <STathread()> _
    Public Shared Sub Main(ByVal args As String())
        Try
            Dim core As ICore = CreateCoreObject(REDIST_LICENSE_KEY)
            System.Console.WriteLine("Core object created!")
        Catch ex As COMException
            System.Console.WriteLine(ex.Message)
        End Try
    End Sub

    ' Create Twebst Core object using IClassFactory2 interface.
    Private Shared Function CreateCoreObject(ByVal licenseKey As [String]) As ICore
        ' Get the IClassFactory2 for twebst library.
        Const INPROC_SERVER As Integer = 1
        Dim twebstGuid As New Guid("173BCDCD-0D75-4CF0-949D-5A07D17384C0")
        Dim factory2Guid As Guid = GetType(IClassFactory2).GUID
        Dim classFactory As IClassFactory2 = CoGetClassObject(twebstGuid, INPROC_SERVER, 0, factory2Guid)

        ' Create a Core object using IClassFactory2 object using the license string.
        Dim coreGuid As Guid = GetType(ICore).GUID
        Dim core As [Object] = Nothing

        classFactory.CreateInstanceLic(Nothing, Nothing, coreGuid, licenseKey, core)
        Return DirectCast(core, ICore)
    End Function


    <DllImport("Ole32.dll", ExactSpelling:=True, PreserveSig:=False)> _
    Private Shared Function CoGetClassObject(<[In]()> ByRef clsid As Guid, ByVal dwContext As Integer, ByVal serverInfo As Integer, <[In]()> ByRef refiid As Guid) As IClassFactory2
    End Function


    '''//////////////////////////////////////////////////////////////////////////////////////////
    Private Shared ReadOnly REDIST_LICENSE_KEY As [String] = "LICENSE KEY FROM PURCHASE ORDER"
End Class



' IClassFactory2 COM interface definition.
<ComImport(), Guid("B196B28F-BAB4-101A-B69C-00AA00341D07"), InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)> _
Friend Interface IClassFactory2
    Sub CreateInstance(<[In](), MarshalAs(UnmanagedType.[Interface])> ByVal unused As Object, <[In]()> ByRef refiid As Guid, <Out(), MarshalAs(UnmanagedType.LPArray)> ByVal ppunk As Object())
    Sub LockServer(ByVal fLock As Integer)
    Sub GetLicInfo(<Out()> ByVal licInfo As IntPtr)
    Sub RequestLicKey(<[In](), MarshalAs(UnmanagedType.U4)> ByVal dwReserved As Integer, <Out(), MarshalAs(UnmanagedType.LPArray)> ByVal pBstrKey As String())
    Sub CreateInstanceLic(<[In](), MarshalAs(UnmanagedType.[Interface])> ByVal pUnkOuter As Object, <[In](), MarshalAs(UnmanagedType.[Interface])> ByVal pUnkReserved As Object, <[In]()> ByRef riid As Guid, <[In](), MarshalAs(UnmanagedType.BStr)> ByVal bstrKey As String, <Out(), MarshalAs(UnmanagedType.[Interface])> ByRef ppVal As Object)
End Interface
