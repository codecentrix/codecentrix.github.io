/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HelpIDs.h"
#include "Speller.h"
#include "LanguageSpellers.h"

extern HINSTANCE g_hInstance;



STDMETHODIMP CSpeller::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISpeller
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}

	return S_FALSE;
}


STDMETHODIMP CSpeller::get_language(BSTR* pVal)
{
	if (NULL == pVal)
	{
		SetComErrorMessage(IDS_INVALID_ARGUMENT, IDH_SPELLER_LANGUAGE);
		return E_INVALIDARG;
	}

	CComBSTR bstrLanguage = m_bstrLanguage;
	*pVal = bstrLanguage.Detach();

	return S_OK;
}


STDMETHODIMP CSpeller::put_language(BSTR bstrNewVal)
{
	if (NULL == bstrNewVal)
	{
		SetComErrorMessage(IDS_INVALID_ARGUMENT, IDH_SPELLER_LANGUAGE);
		return E_INVALIDARG;
	}

	if (wcsicmp(bstrNewVal, ROMANIAN_LANGUAGE) && wcsicmp(bstrNewVal, ENGLISH_LANGUAGE))
	{
		SetComErrorMessage(IDS_LANGUAGE_NOT_SUPPORTED, IDH_SPELLER_LANGUAGE);
		return E_INVALIDARG;
	}

	m_bstrLanguage = bstrNewVal;
	return S_OK;
}


STDMETHODIMP CSpeller::Translate(LONGLONG number, BSTR* pBstrText)
{
	if (NULL == pBstrText)
	{
		SetComErrorMessage(IDS_INVALID_ARGUMENT, IDH_SPELLER_TRANSLATE);
		return E_INVALIDARG;
	}

	if (number < 0)
	{
		SetComErrorMessage(IDS_NEGATIVE_NUMBER, IDH_SPELLER_TRANSLATE);
		return E_INVALIDARG;
	}

	if (!wcsicmp(m_bstrLanguage, ROMANIAN_LANGUAGE))
	{
		// Translate to romanian.
		*pBstrText = CComBSTR(NumberToStringRO(number).c_str()).Detach();

		if (L'\0' == pBstrText[0])
		{
			SetComErrorMessage(IDS_INTERNAL_TRANSLATION_ERROR, IDH_SPELLER_GENERAL);
			return E_FAIL;
		}
	}
	else if (!wcsicmp(m_bstrLanguage, ENGLISH_LANGUAGE))
	{
		// Translate to english.
		*pBstrText = CComBSTR(NumberToStringEN(number).c_str()).Detach();

		if (L'\0' == pBstrText[0])
		{
			SetComErrorMessage(IDS_INTERNAL_TRANSLATION_ERROR, IDH_SPELLER_GENERAL);
			return E_FAIL;
		}
	}
	else
	{
		ATLASSERT(FALSE);
		return E_FAIL;
	}

	return S_OK;
}


void CSpeller::InitHelpFilePath()
{
	// Find the module name
	TCHAR	szBuffer[MAX_PATH + 1];
	DWORD	dwResult = ::GetModuleFileName(g_hInstance, szBuffer, MAX_PATH + 1);
	_ASSERTE(dwResult != 0);
	UNREFERENCED_PARAMETER(dwResult);

	// Find the last backslash
	TCHAR* baseName = _tcsrchr(szBuffer, _T('\\'));
	if (NULL == baseName)
	{
		// No backslash was found.
		return;
	}
	else
	{
		*baseName = _T('\0');
	}

	USES_CONVERSION;
	m_sHelpFilePath = T2W(szBuffer);
	m_sHelpFilePath += L"\\NumberSpeller.chm";
}
