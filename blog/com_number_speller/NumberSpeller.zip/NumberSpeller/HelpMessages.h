/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#pragma once

#define TRANSLATE_MSG_HELP "Translate the number to text according to specified language."
#define LANGUAGE_MSG_HELP  "Set the target language for translation."
