/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#pragma once
#include "resource.h"       // main symbols
#include "NumberSpeller.h"


const WCHAR ROMANIAN_LANGUAGE[] = L"RO";
const WCHAR ENGLISH_LANGUAGE [] = L"EN";



class ATL_NO_VTABLE CSpeller : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSpeller, &CLSID_Speller>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISpeller, &IID_ISpeller, &LIBID_NumberSpellerLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CSpeller()
	{
		m_bstrLanguage = ROMANIAN_LANGUAGE;
		InitHelpFilePath();
	}


DECLARE_REGISTRY_RESOURCEID(IDR_SPELLER)

BEGIN_COM_MAP(CSpeller)
	COM_INTERFACE_ENTRY(ISpeller)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

	// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease() 
	{
	}

public:
	STDMETHOD(get_language)(BSTR* pVal);
	STDMETHOD(put_language)(BSTR newVal);
	STDMETHOD(Translate)   (LONGLONG number, BSTR* pBstrText);


private:
	HRESULT SetComErrorMessage(UINT nMsgId, DWORD dwHelpID)
	{
		return Error(nMsgId, dwHelpID, m_sHelpFilePath.c_str());
	}

	void InitHelpFilePath();

private:
	CComBSTR m_bstrLanguage;
	wstring  m_sHelpFilePath;
};

OBJECT_ENTRY_AUTO(__uuidof(Speller), CSpeller)
