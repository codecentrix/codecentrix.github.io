//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NumberSpeller.rc
//
#define IDS_PROJNAME                    100
#define IDR_NUMBERSPELLER               101
#define IDR_SPELLER                     102
#define IDS_LANGUAGE_NOT_SUPPORTED      512
#define IDS_INVALID_ARGUMENT            513
#define IDS_NEGATIVE_NUMBER             514
#define IDS_INTERNAL_TRANSLATION_ERROR  515

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
