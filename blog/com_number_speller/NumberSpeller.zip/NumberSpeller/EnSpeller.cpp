/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#include "stdafx.h"

const TCHAR* const NUMBERS_UP_TO_20[] =
{
	_T("zero"),     _T("one"),     _T("two"),      _T("three"),    _T("four"),
	_T("five"),     _T("six"),     _T("seven"),    _T("eight"),    _T("nine"),
	_T("ten"),      _T("eleven"),  _T("twelve"),   _T("thirteen"), _T("fourteen"),
	_T("fifteen"),  _T("sixteen"), _T("seventeen"), _T("eighteen"), _T("nineteen")
};

const TCHAR* const NUMBERS_MULTIPLE_OF_10[] =
{
	_T("twenty"), _T("thirty"),  _T("fourty"), _T("fifty"),
	_T("sixty"),  _T("seventy"), _T("eighty"), _T("ninety")
};


tstring NumberToStringEN(INT64 nNumber)
{
	if (nNumber < 0)
	{
		return _T("");
	}

	if (nNumber < 20)
	{
		return NUMBERS_UP_TO_20[nNumber];
	}

	tstring sResult;
	INT64   nCrntNumber = nNumber / 1000000000;

	if (nCrntNumber > 0)
	{
		sResult = NumberToStringEN(nCrntNumber);
		sResult += _T(" billion");
		nNumber %= 1000000000;
	}

	nCrntNumber = nNumber / 1000000;
	if (nCrntNumber > 0)
	{
		sResult = NumberToStringEN(nCrntNumber);
		sResult += _T(" million");
		nNumber %= 1000000;
	}

	nCrntNumber = nNumber / 1000;
	if (nCrntNumber > 0)
	{
		sResult = NumberToStringEN(nCrntNumber);
		sResult += _T(" thousand");
		nNumber %= 1000;
	}

	nCrntNumber = nNumber / 100;
	if (nCrntNumber > 0)
	{
		sResult = NumberToStringEN(nCrntNumber);
		sResult += _T(" hundred");
		nNumber %= 100;
	}

	if ((0 < nNumber) && (nNumber < 20))
	{
		sResult += _T(" ");
		sResult += NumberToStringEN(nNumber);
	}
	else
	{
		nCrntNumber = nNumber / 10;
		if (nCrntNumber > 0)
		{
			sResult += _T(" ");
			sResult += NUMBERS_MULTIPLE_OF_10[nCrntNumber - 2];
			nNumber %= 10;
		}

		nCrntNumber = nNumber;
		if (nCrntNumber > 0)
		{
			sResult += _T(" ");
			sResult += NumberToStringEN(nCrntNumber);
		}
	}

	if (sResult[sResult.length() - 1] == _T(' '))
	{
		// Erase last space.
		sResult.erase(sResult.length() - 1, 1);
	}

	return sResult;
}
