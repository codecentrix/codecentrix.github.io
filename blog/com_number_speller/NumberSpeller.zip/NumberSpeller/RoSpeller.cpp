/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#include "stdafx.h"

struct NumberWordException
{
	TCHAR* m_numberWord;
	INT64  m_number;

	bool operator < (const NumberWordException& rightOp) const
	{
		return m_number < rightOp.m_number;
	}

	bool operator < (INT64 nRightOp) const
	{
		return m_number < nRightOp;
	}
};

const NumberWordException wordExceptions[] = 
{
	{ _T("zero"),                   0 },
	{ _T("unu"),                    1 },
	{ _T("doi"),                    2 },
	{ _T("trei"),                   3 },
	{ _T("patru"),                  4 },
	{ _T("cinci"),                  5 },
	{ _T("sase"),                   6 },
	{ _T("sapte"),                  7 },
	{ _T("opt"),                    8 },
	{ _T("noua"),                   9 },
	{ _T("zece"),                  10 },
	{ _T("unsprezece"),            11 },
	{ _T("doisprezece"),           12 },
	{ _T("treisprezece"),          13 },
	{ _T("patrusprezece"),         14 },
	{ _T("cincisprezece"),         15 },
	{ _T("saisprezece"),           16 },
	{ _T("saptesprezece"),         17 },
	{ _T("optsprezece"),           18 },
	{ _T("nouasprezece"),          19 },
	{ _T("o suta"),               100 },
	{ _T("o mie"),               1000 },
	{ _T("un milion"),        1000000 },
	{ _T("un miliard"),    1000000000 },
};

const int numberOfWordExceptions = sizeof(wordExceptions) / sizeof(wordExceptions[0]);


tstring NumberToStringException(INT64 nNumber, BOOL bVariation = TRUE)
{
	if (bVariation)
	{
		if (2 == nNumber)
		{
			return _T("doua");
		}
		else if (1 == nNumber)
		{
			return _T("una");
		}
	}

	const NumberWordException* pBegin = wordExceptions;
	const NumberWordException* pEnd   = wordExceptions + numberOfWordExceptions;
	const NumberWordException* itFind = std::lower_bound(pBegin, pEnd, nNumber);

	if ((itFind !=pEnd) && !(nNumber < itFind->m_number))
	{
		return itFind->m_numberWord;
	}
	else
	{
		return _T("");
	}
}


tstring NumberToStringRecursive(INT64 nParamNumber, BOOL bVariation = FALSE)
{
	if (nParamNumber < 0)
	{
		return _T("");
	}

	tstring sResult;
	INT64   nNumber     = nParamNumber;
	INT64   nCrntNumber = nNumber / 1000000000;

	sResult = NumberToStringException(nNumber, bVariation);
	if (!sResult.empty())
	{
		return sResult;
	}

	if (nCrntNumber > 1)
	{
		sResult += NumberToStringRecursive(nCrntNumber, TRUE);
		sResult += _T(" miliarde ");
		nNumber %= 1000000000;
	}
	else if (nCrntNumber > 0)
	{
		sResult += NumberToStringRecursive(1000000000);
		sResult += _T(" ");
		nNumber %= 1000000000;
	}

	nCrntNumber = nNumber / 1000000;
	if (nCrntNumber > 1)
	{
		sResult += NumberToStringRecursive(nCrntNumber, nCrntNumber % 10 != 1);
		sResult += _T(" milioane ");
		nNumber %= 1000000;
	}
	else if (nCrntNumber > 0)
	{
		sResult += NumberToStringRecursive(1000000);
		sResult += _T(" ");
		nNumber %= 1000000;
	}

	nCrntNumber = nNumber / 1000;
	if (nCrntNumber > 1)
	{
		sResult += NumberToStringRecursive(nCrntNumber, TRUE);
		if (nCrntNumber % 100 >= 20)
		{
			sResult += _T(" de");
		}

		sResult += _T(" mii ");
		nNumber %= 1000;
	}
	else if (nCrntNumber > 0)
	{
		sResult += NumberToStringRecursive(1000);
		sResult += _T(" ");
		nNumber %= 1000;
	}

	nCrntNumber = nNumber / 100;
	if (nCrntNumber > 1)
	{
		sResult += NumberToStringRecursive(nCrntNumber, TRUE);
		sResult += _T(" sute ");
		nNumber %= 100;
	}
	else if (nCrntNumber > 0)
	{
		sResult += NumberToStringRecursive(100);
		sResult += _T(" ");
		nNumber %= 100;
	}

	nCrntNumber = nNumber;
	if (nCrntNumber >= 20)
	{
		nCrntNumber = nNumber / 10;
		sResult += NumberToStringRecursive(nCrntNumber, TRUE);
		sResult += _T("zeci ");
		nNumber %= 10;

		if (nNumber != 0)
		{
			sResult += _T("si ");
		}
	}
	else if (nCrntNumber > 0)
	{
		sResult += NumberToStringRecursive(nCrntNumber, bVariation);
		sResult += _T(" ");
		nNumber /= 20;
	}

	if (nNumber != 0)
	{
		sResult += NumberToStringRecursive(nNumber, bVariation);
	}

	if (sResult[sResult.length() - 1] == _T(' '))
	{
		// Erase last space.
		sResult.erase(sResult.length() - 1, 1);
	}

	return sResult;
}


tstring NumberToStringRO(INT64 nParamNumber)
{
	return NumberToStringRecursive(nParamNumber);
}
