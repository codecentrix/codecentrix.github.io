/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#pragma once

// ICore help context IDs.
#define IDH_SPELLER_TRANSLATE 1000
#define IDH_SPELLER_LANGUAGE  1001
#define IDH_SPELLER_GENERAL   1002
