

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Sun Jul 22 09:01:11 2007
 */
/* Compiler settings for .\NumberSpeller.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__


#ifndef __NumberSpeller_h__
#define __NumberSpeller_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISpeller_FWD_DEFINED__
#define __ISpeller_FWD_DEFINED__
typedef interface ISpeller ISpeller;
#endif 	/* __ISpeller_FWD_DEFINED__ */


#ifndef __Speller_FWD_DEFINED__
#define __Speller_FWD_DEFINED__

#ifdef __cplusplus
typedef class Speller Speller;
#else
typedef struct Speller Speller;
#endif /* __cplusplus */

#endif 	/* __Speller_FWD_DEFINED__ */


#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_NumberSpeller_0000 */
/* [local] */ 

#pragma once
#pragma once


extern RPC_IF_HANDLE __MIDL_itf_NumberSpeller_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_NumberSpeller_0000_v0_0_s_ifspec;


#ifndef __NumberSpellerLib_LIBRARY_DEFINED__
#define __NumberSpellerLib_LIBRARY_DEFINED__

/* library NumberSpellerLib */
/* [helpfile][helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_NumberSpellerLib;

#ifndef __ISpeller_INTERFACE_DEFINED__
#define __ISpeller_INTERFACE_DEFINED__

/* interface ISpeller */
/* [unique][helpcontext][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISpeller;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F4803352-4BCA-485F-A6B6-93F86C500ACC")
    ISpeller : public IDispatch
    {
    public:
        virtual /* [helpcontext][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_language( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpcontext][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_language( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpcontext][helpstring][id] */ HRESULT STDMETHODCALLTYPE Translate( 
            /* [in] */ LONGLONG number,
            /* [retval][out] */ BSTR *pBstrText) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISpellerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISpeller * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISpeller * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISpeller * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISpeller * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISpeller * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISpeller * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISpeller * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpcontext][helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_language )( 
            ISpeller * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpcontext][helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_language )( 
            ISpeller * This,
            /* [in] */ BSTR newVal);
        
        /* [helpcontext][helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Translate )( 
            ISpeller * This,
            /* [in] */ LONGLONG number,
            /* [retval][out] */ BSTR *pBstrText);
        
        END_INTERFACE
    } ISpellerVtbl;

    interface ISpeller
    {
        CONST_VTBL struct ISpellerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISpeller_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISpeller_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISpeller_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISpeller_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISpeller_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISpeller_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISpeller_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISpeller_get_language(This,pVal)	\
    (This)->lpVtbl -> get_language(This,pVal)

#define ISpeller_put_language(This,newVal)	\
    (This)->lpVtbl -> put_language(This,newVal)

#define ISpeller_Translate(This,number,pBstrText)	\
    (This)->lpVtbl -> Translate(This,number,pBstrText)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpcontext][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISpeller_get_language_Proxy( 
    ISpeller * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISpeller_get_language_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpcontext][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISpeller_put_language_Proxy( 
    ISpeller * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISpeller_put_language_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpcontext][helpstring][id] */ HRESULT STDMETHODCALLTYPE ISpeller_Translate_Proxy( 
    ISpeller * This,
    /* [in] */ LONGLONG number,
    /* [retval][out] */ BSTR *pBstrText);


void __RPC_STUB ISpeller_Translate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISpeller_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Speller;

#ifdef __cplusplus

class DECLSPEC_UUID("A56A1BD3-0924-4912-9D66-D7A131391B77")
Speller;
#endif
#endif /* __NumberSpellerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


