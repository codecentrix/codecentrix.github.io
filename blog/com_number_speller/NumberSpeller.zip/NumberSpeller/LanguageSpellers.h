#pragma once

tstring NumberToStringRO(INT64 nParamNumber);
tstring NumberToStringEN(INT64 nNumber);
