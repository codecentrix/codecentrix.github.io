/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////

// Create the speller object.
var speller = new ActiveXObject("NumberSpeller.Speller");

// Set romanian language
speller.language = "en";

////////////////////////////////////////////
// Modify the  number constant below.
var numberToTranslate = 101001;

// Translate number to text.
try
{
	var textNumber = speller.Translate(numberToTranslate);
	WScript.Echo(textNumber);
}
catch (e)
{
	// Display details about any thrown exceptions.
	WScript.Echo(e.name + ": " + e.description + "  " + e.number);
}
