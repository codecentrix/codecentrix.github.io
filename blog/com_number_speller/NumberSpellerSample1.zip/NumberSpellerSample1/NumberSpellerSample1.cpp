/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////
#include "stdafx.h"
#import "progid:NumberSpeller.Speller" // The NumberSpeller component must be registered.


int _tmain(int argc, _TCHAR* argv[])
{
	::CoInitialize(NULL);

// Open a new scope where smart pointers will live.
// At the end of the scope they will be automatically released.
// This ensures CoUninitialize will be called after all the COM pointers are released.
{
	// Read a number.
	long number;
	wcout << L"Enter a number:";
	wcin >> number;

	try
	{
		// Convert the number.
		NumberSpellerLib::ISpellerPtr spSpeller(L"NumberSpeller.Speller");
		spSpeller->language = _bstr_t("ro");

		// Convert the number to text in Romanian language.
		_bstr_t textNumber = spSpeller->Translate(number);

		// Display the text.
		wcout << textNumber << L'\n';
	}
	catch (_com_error comErr)
	{
		// Display the error code.
		wcout << L"Error, hRes=" << std::hex << comErr.Error() << L"\n";
	}
}
	::CoUninitialize();
	return 0;
}
