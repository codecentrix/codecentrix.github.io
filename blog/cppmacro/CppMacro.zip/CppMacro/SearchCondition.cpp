//////////////////////////////////////////////////////////////
// (c)2009 CodeCentrix Software. All rights reserved.
//////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "SearchCondition.h"


SearchCondition::SearchCondition()
{
	Init();
}


SearchCondition::SearchCondition(BSTR bstrCondition)
{
	ATLASSERT(bstrCondition != NULL);
	Init();
	AddBSTR(bstrCondition);
}


SearchCondition::SearchCondition(LPCSTR szCondition)
{
	USES_CONVERSION;
	ATLASSERT(szCondition != NULL);
	Init();
	AddBSTR(CComBSTR(szCondition));
}


SearchCondition::SearchCondition(LPCWSTR szCondition)
{
	ATLASSERT(szCondition != NULL);
	Init();
	AddBSTR(CComBSTR(szCondition));
}


SearchCondition::~SearchCondition()
{
	CleanUp();
}


void SearchCondition::CleanUp()
{
	if (m_pSafeArray != NULL)
	{
		HRESULT hRes = ::SafeArrayDestroy(m_pSafeArray);
		ATLASSERT(SUCCEEDED(hRes));
		m_pSafeArray = NULL;
	}
}


void SearchCondition::Init()
{
	m_nNumberElements = 0;

	SAFEARRAYBOUND rgsabound = { 0, 0 };
	m_pSafeArray = ::SafeArrayCreate(VT_VARIANT, 1, &rgsabound);
	ATLASSERT(m_pSafeArray != NULL);
}


void SearchCondition::AddBSTR(BSTR bstrNew)
{
	// Ignore empty strings.
	if ((NULL == bstrNew) || (L'\0' == bstrNew[0]))
	{
		return;
	}

	// Resize the array.
	CComVariant    varNew(bstrNew);
	SAFEARRAYBOUND rgsabound = { ++m_nNumberElements, 0 };

	HRESULT hRes = ::SafeArrayRedim(m_pSafeArray, &rgsabound);
	ATLASSERT(SUCCEEDED(hRes));

	// Add the string to array.
	long nIndex = { m_nNumberElements - 1 };
	hRes = ::SafeArrayPutElement(m_pSafeArray, &nIndex, &varNew);
	ATLASSERT(SUCCEEDED(hRes));
}


void SearchCondition::operator+=(BSTR bstrCondition)
{
	ATLASSERT(bstrCondition != NULL);
	AddBSTR(bstrCondition);
}


void SearchCondition::operator+=(LPCSTR szCondition)
{
	USES_CONVERSION;
	ATLASSERT(szCondition != NULL);
	AddBSTR(CComBSTR(szCondition));
}


void SearchCondition::operator+=(LPCWSTR szCondition)
{
	ATLASSERT(szCondition != NULL);
	AddBSTR(CComBSTR(szCondition));
}


SearchCondition& SearchCondition::operator=(BSTR bstrCondition)
{
	ATLASSERT(bstrCondition != NULL);
	CleanUp();
	Init();
	AddBSTR(bstrCondition);

	return *this;
}


SearchCondition& SearchCondition::operator=(LPCSTR szCondition)
{
	ATLASSERT(szCondition != NULL);
	CleanUp();
	Init();
	AddBSTR(CComBSTR(szCondition));

	return *this;
}


SearchCondition& SearchCondition::operator=(LPCWSTR szCondition)
{
	ATLASSERT(szCondition != NULL);
	CleanUp();
	Init();
	AddBSTR(CComBSTR(szCondition));

	return *this;
}
