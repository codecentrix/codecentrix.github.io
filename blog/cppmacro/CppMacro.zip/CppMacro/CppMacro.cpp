////////////////////////////////////////////////////////////////
// (c)2009 CodeCentrix Software. All rights reserved.
// http://www.codecentrix.com
////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "SearchCondition.h"


int _tmain(int argc, _TCHAR* argv[])
{
	::CoInitialize(NULL);

	try
	{
		// Create the Core object.
		ICorePtr pCore;
		HRESULT  hRes = pCore.CreateInstance(_T("Twebst.Core"));
		if (FAILED(hRes))
		{
			// Failed to create the Core object.
			throw _com_error(hRes);
		}

		// Start a new Internet Explorer instance and navigate to a given URL.
		IBrowserPtr pBrowser = pCore->StartBrowser("http://www.google.com/");

		// Find search edit box in page and type some text into it.
		IElementPtr pSearchEdit = pBrowser->FindElement("input text", SearchCondition("name=q"));
		pSearchEdit->InputText("codecentrix");

        // Find search button and click it.
        IElementPtr pSearchBtn = pBrowser->FindElement("input submit", SearchCondition("text=Google Search"));
        pSearchBtn->Click();

        // Find the <div> element where the result are displayed.
        IElementPtr pResultDiv = pBrowser->FindElement("div", SearchCondition("id=res"));

        // Get all found results and print them in console.
        IElementListPtr pResultList = pResultDiv->FindAllElements("h3", SearchCondition());

        // Display only the header result (text and url).
        for (int i = 0; i < pResultList->length; ++i)
        {
            IElementPtr                   pCrntResult  = pResultList->Getitem(i); // Get current <h3> in the list.
			IElementPtr                   pCrntAnchor  = pCrntResult->FindElement("a", SearchCondition()); // Find first and only anchor inside <h3>
			CComQIPtr<IHTMLAnchorElement> spCrntAnchor = pCrntAnchor->nativeElement;

			// Get URL from IHTMLAnchorElement.
			CComBSTR bstrURL = "";
			spCrntAnchor->get_href(&bstrURL);

			// Display results.
			wcout << pCrntResult->text << L"\n" << bstrURL.m_str << L"\n\n";
        }
	}
	catch (_com_error comErr)
	{
		cout << "Error, hRes=" << std::hex << comErr.Error() << "\n";
	}

	::CoUninitialize();

	cout << "\nPress any key ...\n";
	_getch();

	return 0;
}
