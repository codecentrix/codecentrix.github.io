//////////////////////////////////////////////////////////////
// (c)2009 CodeCentrix Software. All rights reserved.
//////////////////////////////////////////////////////////////

#pragma once

class SearchCondition
{
public:
	 SearchCondition();
	 SearchCondition(BSTR    bstrCondition);
	 SearchCondition(LPCSTR  szCondition);
	 SearchCondition(LPCWSTR szCondition);
	~SearchCondition();

	void operator+=(BSTR    bstrCondition);
	void operator+=(LPCSTR  szCondition);
	void operator+=(LPCWSTR szCondition);
	operator LPSAFEARRAY() { return m_pSafeArray; }
	SearchCondition& operator=(BSTR    bstrCondition);
	SearchCondition& operator=(LPCSTR  szCondition);
	SearchCondition& operator=(LPCWSTR szCondition);

private:
	// Avoid duplicating search conditions.
	SearchCondition& operator=(const SearchCondition&);
	SearchCondition(const SearchCondition&);

	void Init();
	void AddBSTR(BSTR bstrNew);
	void CleanUp();

private:
	SAFEARRAY* m_pSafeArray;
	long       m_nNumberElements;
};
