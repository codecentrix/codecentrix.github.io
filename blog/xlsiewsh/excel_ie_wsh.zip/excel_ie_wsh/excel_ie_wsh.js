// Use the command line below to launch the script (or just double click the .js file):
// %windir%\system32\wscript.exe TwebstScript.js
// On Windows 64bit use wscript.exe from %windir%\SysWOW64 directory to launch the .js file

// Create Excel automation object.
var excelApp = new ActiveXObject("Excel.Application");
excelApp.Visible = true;

// Get the name of the XLS document.
var fileSystem = WScript.CreateObject("Scripting.FileSystemObject");
var xlsFile    = fileSystem.GetFolder(".") + "\\trans.xls";

// Open XLS document.
excelApp.Workbooks.Open(xlsFile);

// Create Twebst core object.
var core    = new ActiveXObject('Twebst.Core');
var browser = core.StartBrowser('http://www.google.com/');

for (var i = 1; i <= 5; ++i)
{
	// Get currnet text to translate from XLS document.
	var textToTranslate = excelApp.ActiveSheet.Cells(i, 1).Formula;

	// Web automation part implemented with Twebst Automatio Studio.
	browser.Navigate('http://www.google.com/language_tools?hl=en');
	browser.FindElement('textarea', 'id=source').InputText(textToTranslate);
	browser.FindElement('select', 'name=sl').Select('English');
	browser.FindElement('select', 'name=tl').Select('French');
	browser.FindElement('input submit', 'text=Translate').Click();

	// Get the reszult and save it into XLS document.
	var translatedText = browser.FindElement('span', 'id=result_box').text;
	excelApp.ActiveSheet.Cells(i, 2).Formula = translatedText;
}
