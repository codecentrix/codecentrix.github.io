0). You need Excel installed for the WSH script to work.
1). Install "Twebst Automation Studio" from http://www.codecentrix.com/
2). Unzip excel_ie_wsh.js and trans.xls in the same folder.
3). Launch (double click) excel_ie_wsh.js to see the demo.
    Command line: %windir%\system32\wscript.exe TwebstScript.js
    On Windows 64bit use wscript.exe from %windir%\SysWOW64 directory to launch the .js file
