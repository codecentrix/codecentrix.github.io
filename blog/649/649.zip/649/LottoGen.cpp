// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/

#include "stdafx.h"



enum ACTION_TYPE
{
	GENERATE_ALL,
	GENERATE_N_RANDOM,
	GENERATE_ALL_REVERSE,
	FIND_MISSING,
	DISPLAY_HELP_MSG,
};


union PairOfSix
{
	struct
	{
		BYTE m_unused8;
		BYTE m_unused7;
		BYTE m_n6;
		BYTE m_n5;
		BYTE m_n4;
		BYTE m_n3;
		BYTE m_n2;
		BYTE m_n1;
	};

	__int64 m_pairAsInt64;

	bool operator < (const PairOfSix& pair)
	{
		return m_pairAsInt64 < pair.m_pairAsInt64;
	}

	bool operator == (const PairOfSix& pair)
	{
		return m_pairAsInt64 == pair.m_pairAsInt64;
	}

	bool operator != (const PairOfSix& pair)
	{
		return m_pairAsInt64 != pair.m_pairAsInt64;
	}
};




void DisplayHelpMsg()
{
	_tprintf(_T("Usage: LotoGen <options> [file] [file2]\n"));
	_tprintf(_T("Options:\n"));
	_tprintf(_T("   /all       Generate all combinations of 6 numbers in the target file.\n"));
	_tprintf(_T("   /allrev    Generate all combinations of 6 numbers in reverse order.\n"));
	_tprintf(_T("   /random N  Generate \"n\" random combinations in the target file.\n"));
	_tprintf(_T("   /find      Find missing pairs and write them in the [file2] file.\n"));
	_tprintf(_T("   /help      Display this help message.\n"));
	_tprintf(_T("   [file]     The name of the file where the combinations will be written.\n"));
	_tprintf(_T("              If no file is provided, combinations will be printed to console.\n\n"));
	_tprintf(_T("   [file2]    The name of the file where the missing combinations from [file]\n"));
	_tprintf(_T("              will be written. Both [file] and [file2] must be provided.\n\n"));
}


bool LoadFromFile(LPCTSTR szTargetFile, vector<PairOfSix>& records)
{
	assert(szTargetFile != NULL);

	// Get the size of the file.
	struct _stat buffer;
	if (_tstat(szTargetFile, &buffer) == -1)
	{
		// Can not obtain file info.
		return false;
	}

	long sizeInBytes = buffer.st_size;
	long nRecords    = sizeInBytes / 19;

	FILE* in = _tfopen(szTargetFile,  _T("rt"));
	if (!in)
	{
		return false;
	}

	if (0 == nRecords)
	{
		return false;
	}

	records.clear();
	records.reserve(nRecords);

	// Read records from file.
	for (int i = 0; i < nRecords; ++i)
	{
		if (feof(in))
		{
			// The file might be invalid.
			fclose(in);
			in = NULL;

			return false;
		}

		// Read a record.
		records.push_back(PairOfSix());

		int n1, n2, n3, n4, n5, n6;
		_ftscanf(in, _T("%2d%2d%2d%2d%2d%2d"), &n1, &n2, &n3, &n4, &n5, &n6);
		records[i].m_n1 = n1;
		records[i].m_n2 = n2;
		records[i].m_n3 = n3;
		records[i].m_n4 = n4;
		records[i].m_n5 = n5;
		records[i].m_n6 = n6;
		records[i].m_unused7 = 0;
		records[i].m_unused8 = 0;
	}

	fclose(in);
	in = NULL;

	return true;
}


bool FindMissingRecords(LPCTSTR szTargetFile, LPCTSTR szOutFile)
{
	if ((NULL == szTargetFile) || (NULL == szOutFile))
	{
		return false;
	}

	_tprintf(_T("This might take few minutes. Please wait.\n"));
	DWORD dwStart     = ::GetTickCount();
	DWORD dwStartLoad = dwStart;

	// Load records in memory.
	vector<PairOfSix> records;
	if (!LoadFromFile(szTargetFile, records))
	{
		return false;
	}

	// Print the load time.
	DWORD dwLoadEnd = ::GetTickCount();
	DWORD dwLoadTime = (dwLoadEnd - dwStartLoad) / 1000;
	_tprintf(_T("%lu record(s) loaded in memory in %ld seconds\n"), records.size(), dwLoadTime);

	// Sort records.
	DWORD dwSortStart = ::GetTickCount();
	sort(records.begin(), records.end());

	// Print the sort time.
	DWORD dwSortEnd = ::GetTickCount();
	DWORD dwSortTime = (dwSortEnd - dwSortStart);
	_tprintf(_T("%lu record(s) sorted in %ld miliseconds\n"), records.size(), dwSortTime);

	// Open a file if a filename is provided.
	DWORD dwWriteStart = ::GetTickCount();
	FILE* out     = _tfopen(szOutFile,  _T("wt"));
	if (!out)
	{
		// Can not open out file.
		return false;
	}

	// Find missing records.
	int  nDuplicates      = 0;
	int  nWrittenRecords  = 0;
	int  crntSortedRecord = 0;
	bool bEnd = false;

	for (int i1 = 1; i1 <= 44; ++i1)
	{
		for (int i2 = i1 + 1; i2 <= 45; ++i2)
		{
			for (int i3 = i2 + 1; i3 <= 46; ++i3)
			{
				for (int i4 = i3 + 1; i4 <= 47; ++i4)
				{
					for (int i5 = i4 + 1; i5 <= 48; ++i5)
					{
						for (int i6 = i5 + 1; i6 <= 49; ++i6)
						{
							PairOfSix currentRecord;
							currentRecord.m_n1 = i1;
							currentRecord.m_n2 = i2;
							currentRecord.m_n3 = i3;
							currentRecord.m_n4 = i4;
							currentRecord.m_n5 = i5;
							currentRecord.m_n6 = i6;
							currentRecord.m_unused7 = 0;
							currentRecord.m_unused8 = 0;

							if (bEnd || (currentRecord < records[crntSortedRecord]))
							{
								_ftprintf(out, _T("%2d %2d %2d %2d %2d %2d\n"), currentRecord.m_n1, currentRecord.m_n2,
								                                                currentRecord.m_n3, currentRecord.m_n4,
																				currentRecord.m_n5, currentRecord.m_n6);
								nWrittenRecords++;
							}
							else
							{
								// Skip equal elements in records vector.
								int j = crntSortedRecord + 1;
								while (true)
								{
									if (j == records.size())
									{
										bEnd = true;
										break;
									}

									if (currentRecord == records[j])
									{
										nDuplicates++;
										j++;
									}
									else
									{
										break;
									}
								}

								crntSortedRecord = j;
							}
						}
					}
				}
			}
		}
	}

	fclose(out);
	out = NULL;

	// Print time.
	DWORD dwWriteEnd = ::GetTickCount();
	DWORD dwWriteTime = (dwWriteEnd - dwWriteStart) / 1000;
	DWORD dwTotalTime = (dwWriteEnd - dwStart) / 1000;
	_tprintf(_T("%lu record(s) written in %ld seconds\n"), nWrittenRecords, dwWriteTime);
	//_tprintf(_T("%lu duplicate records\n"), nDuplicates);
	_tprintf(_T("Total time: %ld seconds\n"), dwTotalTime);

	return true;
}


bool GenerateRandom(LPCTSTR szTargetFile, unsigned long nHowMuchRandom)
{
	assert(nHowMuchRandom > 0);

	// Open a file if a filename is provided.
	FILE* out = stdout;
	if (szTargetFile != NULL)
	{
		out = _tfopen(szTargetFile,  _T("wt"));
		if (!out)
		{
			return false;
		}
	}

	_tprintf(_T("This might take few minutes. Please wait.\n"));

	int numbers[] = {  1,  2,  3,  4,  5,  6,  7,  8,  9, 10,
	                  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
	                  21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
	                  31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
	                  41, 42, 43, 44, 45, 46, 47, 48, 49 };

	DWORD dwStart = ::GetTickCount();

	// Initialize the random number generator and shuffle the numbers.
	srand(GetTickCount());
	random_shuffle(numbers, numbers + 49);
	
	// Generate nHowMuchRandom random pairs of 6.
	for (unsigned long i = 0; i < nHowMuchRandom; ++i)
	{
		// Generate a pair.
		for (int j = 0; j < 6; ++j)
		{
			// Generate a number between 1 and 49.
			int nCrntRand = (rand() % (49 - j)) + j;
			swap(numbers[j], numbers[nCrntRand]);
			sort(numbers, numbers + 6);
		}

		if (_ftprintf(out, _T("%2d %2d %2d %2d %2d %2d\n"),
		                      numbers[0], numbers[1], numbers[2],
		                      numbers[3], numbers[4], numbers[5]) < 0)
		{
			// Outpupt error.
			return false;
		}
	}

	if (szTargetFile != NULL)
	{
		fclose(out);
	}

	out = NULL;

	// Print time.
	DWORD dwEnd = ::GetTickCount();
	DWORD dwTime = (dwEnd - dwStart) / 1000;
	_tprintf(_T("%lu record(s) generated in %ld seconds\n"), nHowMuchRandom, dwTime);

	return true;
}


bool GenerateAll(LPCTSTR szTargetFile, bool bReverse = false)
{
	// Open a file if a filename is provided.
	FILE* out = stdout;
	if (szTargetFile != NULL)
	{
		out = _tfopen(szTargetFile,  _T("wt"));
		if (!out)
		{
			return false;
		}
	}

	DWORD         dwStart = ::GetTickCount();
	unsigned long nCount  = 0;

	_tprintf(_T("This might take few minutes. Please wait.\n"));

	for (int i1 = 1; i1 <= 44; ++i1)
	{
		for (int i2 = i1 + 1; i2 <= 45; ++i2)
		{
			for (int i3 = i2 + 1; i3 <= 46; ++i3)
			{
				for (int i4 = i3 + 1; i4 <= 47; ++i4)
				{
					for (int i5 = i4 + 1; i5 <= 48; ++i5)
					{
						for (int i6 = i5 + 1; i6 <= 49; ++i6)
						{
							if (!bReverse)
							{
								if (_ftprintf(out, _T("%2d %2d %2d %2d %2d %2d\n"), i1, i2, i3, i4, i5, i6) < 0)
								{
									// Outpupt error.
									return false;
								}
							}
							else
							{
								if (_ftprintf(out, _T("%2d %2d %2d %2d %2d %2d\n"), 50 - i1, 50 - i2, 50 - i3, 50 - i4, 50 - i5, 50 - i6) < 0)
								{
									// Outpupt error.
									return false;
								}
							}

							nCount++;
						}
					}
				}
			}
		}
	}

	if (szTargetFile != NULL)
	{
		fclose(out);
	}

	out = NULL;

	// Print time.
	DWORD dwEnd = ::GetTickCount();
	DWORD dwTime = (dwEnd - dwStart) / 1000;
	_tprintf(_T("%lu record(s) generated in %ld seconds\n"), nCount, dwTime);

	return true;
}


int _tmain(int argc, _TCHAR* argv[])
{
	_tprintf(_T("LotoGen: romanian 6/49 lotery numbers generator\n"));
	_tprintf(_T("This is free software and you are welcome to use it in any way you want.\n\n"));
	_tprintf(_T("http://codecentrix.blogspot.com/\n"));
	_tprintf(_T("http://www.codecentrix.com/\n\n"));


	ACTION_TYPE   actionType;
	unsigned long nHowMuchRandom = 0;
	LPCTSTR       szTargetFile   = NULL;
	LPCTSTR       szOutFile      = NULL;


	// Validate number of parameters.
	if (argc > 4)
	{
		// Wrong command line. At least "option" must be provided.
		DisplayHelpMsg();
		return -1;
	}
	else if (1 == argc)
	{
		// Display a menu.
		actionType = GENERATE_N_RANDOM;
		_tprintf(_T("\n\nHow many records do you want to generate? "));

		int nFieldsRead = _tscanf(_T("%d"), &nHowMuchRandom);
		if ((0 == nFieldsRead) || (nHowMuchRandom <= 0))
		{
			DisplayHelpMsg();
			return -1;
		}
	}
	else
	{
		///////////////////////////////////////////////////////////////////////////
		// Get option from command line.
		if (!_tcsicmp(argv[1], _T("/all")))
		{
			actionType = GENERATE_ALL;
		}
		else if (!_tcsicmp(argv[1], _T("/allrev")))
		{
			actionType = GENERATE_ALL_REVERSE;
		}
		else if (!_tcsicmp(argv[1], _T("/random")))
		{
			actionType = GENERATE_N_RANDOM;
			if (argc < 3)
			{
				// After /random a number should appear.
				DisplayHelpMsg();
				return -1;
			}

			for (TCHAR* pChr = argv[2]; *pChr != _T('\0'); ++pChr)
			{
				if (!_istdigit(*pChr))
				{
					// The parameter is not a valid number.
					DisplayHelpMsg();
					return -1;
				}
			}

			nHowMuchRandom = _ttoi(argv[2]);
			if (0 == nHowMuchRandom)
			{
				// Zero is not allowed.
				DisplayHelpMsg();
				return -1;
			}
		}
		else if (!_tcsicmp(argv[1], _T("/find")))
		{
			actionType = FIND_MISSING;
		}
		else if (!_tcsicmp(argv[1], _T("/help")))
		{
			actionType = DISPLAY_HELP_MSG;
		}
		else
		{
			// No option provided.
			DisplayHelpMsg();
			return -1;
		}

		///////////////////////////////////////////////////////////////////////////
		// Get file from command line.
		int nFileIndex   = (GENERATE_N_RANDOM == actionType ? 3 : 2);
		szTargetFile = (nFileIndex < argc ? argv[nFileIndex] : NULL);
		szOutFile    = (nFileIndex + 1 < argc ? argv[nFileIndex + 1] : NULL);
	}


	switch (actionType)
	{
		case DISPLAY_HELP_MSG:
		{
			DisplayHelpMsg();
			break;
		}

		case GENERATE_ALL:
		{
			if (!GenerateAll(szTargetFile))
			{
				DisplayHelpMsg();
				return -1;
			}

			break;
		}

		case GENERATE_ALL_REVERSE:
		{
			if (!GenerateAll(szTargetFile, true))
			{
				DisplayHelpMsg();
				return -1;
			}

			break;
		}

		case GENERATE_N_RANDOM:
		{
			if (!GenerateRandom(szTargetFile, nHowMuchRandom))
			{
				DisplayHelpMsg();
				return -1;
			}

			break;
		}

		case FIND_MISSING:
		{
			if (!FindMissingRecords(szTargetFile, szOutFile))
			{
				DisplayHelpMsg();
				return -1;
			}

			break;
		}

		default:
		{
			assert(false);
		}
	}

	if (1 == argc)
	{
		system("pause");
	}

	return 0;
}
