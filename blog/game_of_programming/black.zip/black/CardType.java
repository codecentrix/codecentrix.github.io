public class CardType
{
    public static final int SPADES  = 3;
    public static final int HEARTS  = 2;
    public static final int CLUB    = 0;
    public static final int DIAMOND = 1;
}