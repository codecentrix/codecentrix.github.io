import java.util.Vector;
import java.awt.*;
import java.util.Random;

public class Deck extends Canvas implements Runnable
{
    //constructor
    public Deck(BlackJack applet)
    {
        m_Applet = applet;
    }
    
    //public method section
    public void paint(Graphics g){
        if(offscreenGraphics == null){ //executed only at first paint
            Dimension       dim = size();
            offscreenImage = createImage(size().width, size().height);
            offscreenGraphics = offscreenImage.getGraphics();
        }
        
        offscreenGraphics.clearRect(0, 0, size().width, size().height);
        offscreenGraphics.setColor(Color.yellow);
        //draw cards package
        m_cardsPackage.drawCard( offscreenGraphics, 0, 0 );
        
        //draw computer's hand
        for( int i = 0; i < m_computersHand.size(); ++i )
        {
            Card    currentCard = (Card)m_computersHand.elementAt(i);
            int     x = i * Card.getCardSize().width / 2 + Card.getCardSize().width ;
            currentCard.drawCard( offscreenGraphics, x, 0 );
        }
        
        //draw user's hand
        int     y = Card.getCardSize().height;
        y += y / 4;
        for(int i = 0; i < m_usersHand.size(); ++i)
        {
            Card    currentCard = (Card)m_usersHand.elementAt(i);
            int     x = i * Card.getCardSize().width / 2;
            currentCard.drawCard( offscreenGraphics, x, y );
        }
        
        //show pot and total points
        int nHeight = g.getFontMetrics().getHeight();
        String  sStatus = "Your Points       : " + String.valueOf(m_nTotalUser) +
                                "       Your pot: " + String.valueOf(m_nPot) + "$" ;

        offscreenGraphics.drawString(sStatus , 0, size().height - 3 * nHeight);
        offscreenGraphics.drawString(m_sComputerPoints , 0, size().height - 2 * nHeight);
        offscreenGraphics.drawString(m_sMessage, 0, size().height - nHeight);
        
   	    g.drawImage(offscreenImage, 0, 0, this);
    }

    public void run() //run the code for stay in another thread
    {
        m_nTotalComputer = 0;
        m_nNumberOfAceForComputer = 0;
        while( m_nTotalComputer < m_nTotalUser && m_nTotalComputer <=21){
            try{
                m_stayThread.sleep(700);
            }
            catch (InterruptedException e){} //sleep few miliseconds

            Card        newCard = generateNewCard() ;

            m_computersHand.addElement( newCard );
            m_nTotalComputer += newCard.getValue();

            if(newCard.getCard() == 1) //we've got an ace
                m_nNumberOfAceForComputer++;
            
            while(m_nTotalComputer >21 && m_nNumberOfAceForComputer >0){
                m_nNumberOfAceForComputer--;
                m_nTotalComputer -= 10;
            }
            m_sComputerPoints = "Computer Points: " + String.valueOf(m_nTotalComputer);
            repaint();
        }

        if(m_nTotalComputer >= m_nTotalUser && m_nTotalComputer <= 21){
            m_sMessage = "Computer won.";
            m_nPot -=10;
            
            if(m_nPot == 0){
                m_Applet.m_hitButton.disable();
                m_Applet.m_StayButton.disable();
                m_Applet.m_newGameButton.enable();
                m_sMessage = "You left all your money. Press New Game";
                repaint();
                return;
            }
        }
        else{
            m_sMessage = "You've just won 10$.";
            m_nPot +=10;
        }
            
        //m_Applet.m_StayButton.enable();
        m_Applet.m_hitButton.enable();
        m_Applet.m_newGameButton.enable();
        m_sMessage += " Press Hit to continue";
    }

    public void stay(){
       m_Applet.m_StayButton.disable();
       m_Applet.m_hitButton.disable();
       m_Applet.m_newGameButton.disable();
       m_sMessage = "Computer turn. Please wait";

       //do what you have to do
       //create the new thread that will execute the Deck.run code
       m_stayThread = new Thread(this);
       m_stayThread.start();
    }

    public void hit(){
        m_Applet.m_StayButton.enable();
        if(m_nTotalUser >= 21 || m_nTotalComputer != 0)
        {
            m_sComputerPoints = "";
            m_nNumberOfAceForUser = 0;
            m_nTotalUser = 0;
            m_nTotalComputer = 0;
            m_usersHand.removeAllElements();
            m_computersHand.removeAllElements();
            m_sMessage = "";
        }

        Card        newCard = generateNewCard() ;
        
        m_usersHand.addElement( newCard );
        m_nTotalUser += newCard.getValue();
        
        if(newCard.getCard() == 1) //we've got an ace
            m_nNumberOfAceForUser++;

        if(m_nTotalUser == 21) //user won
        {
            m_nPot += 10;
            m_Applet.m_StayButton.disable();
            m_sMessage = "You've just won 10$. Press Hit to continue";
        }

        while(m_nTotalUser >21 && m_nNumberOfAceForUser >0){
            m_nNumberOfAceForUser--;
            m_nTotalUser -= 10;
        }
        
        if(m_nTotalUser > 21) //user left
        {
            m_nPot -=10;
            if(m_nPot == 0){
                m_Applet.m_hitButton.disable();
                m_Applet.m_StayButton.disable();
                m_sMessage = "You left all your money. Press New Game";
                repaint();
                return;
            }
            m_Applet.m_StayButton.disable();
            m_sMessage = "You've just left 10$. Press Hit to continue";
        }
        repaint();
    }

    public void newGame(){
        m_sComputerPoints = "";
        m_nNumberOfAceForUser = 0;
        m_nNumberOfAceForComputer = 0;
        m_nPot = 100;
        m_nTotalUser = 0;
        m_nTotalComputer = 0;
        m_computersHand.removeAllElements();
        m_usersHand.removeAllElements();
        m_sMessage = "";
        hit();
    }

    private Card generateNewCard(){
        int nCard, nSign;
        do{
            nCard = m_randomNo.nextInt();  //the value of the new generated card
            nSign = m_randomNo.nextInt();  //the sign of the card
		    if( nCard < 0 )
			    nCard *= -1;
    		if( nSign < 0 )
	    		nSign *= -1;

            nCard = nCard % 14 + 1;
            if( nCard == 11 )      //if we've got an ace
                nCard = 1;

            nSign = nSign % 4;
        }
        while(alreadyExist(nCard, nSign));

        return new Card( nCard, nSign );
    }

    private boolean alreadyExist(int nCard, int nSign){
        for(int i = 0; i < m_usersHand.size(); ++i){
            Card    currentCard = (Card)m_usersHand.elementAt(i);
            if(currentCard.getCard() == nCard && currentCard.getCardType() == nSign)
                return true;
        }
        
        for(int i = 0; i < m_computersHand.size(); ++i){
            Card    currentCard = (Card)m_computersHand.elementAt(i);
            if(currentCard.getCard() == nCard && currentCard.getCardType() == nSign)
                return true;
        }
        return false;
    }
    
    public void update( Graphics g){
        //to prevent the erase of the canvas
        paint( g );
    }

    //private members section
    private int             m_nNumberOfAceForUser;
    private int             m_nNumberOfAceForComputer;
    private Vector          m_computersHand = new Vector();
    private Vector          m_usersHand = new Vector();
    private static Card     m_cardsPackage = new Card( 0, CardType.HEARTS );
    private Random          m_randomNo = new Random();
    private int             m_nTotalUser;
    private int             m_nTotalComputer;
    private int             m_nPot;
    private BlackJack       m_Applet = null;
    private String          m_sMessage = new String(); //for messages for user
    private String          m_sComputerPoints = new String();
    private Thread          m_stayThread;
    private Image           offscreenImage = null;
    private Graphics        offscreenGraphics = null;
}
