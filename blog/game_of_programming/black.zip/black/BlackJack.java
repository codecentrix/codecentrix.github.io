import java.awt.*;
import java.applet.*;

public class BlackJack extends Applet implements Runnable {

	void mStayButton_Clicked(Event event) {
	    m_deckCanvas.stay();
	}
    
	void mHitButton_Clicked(Event event) {
   	    m_deckCanvas.hit();
	}

	void mNewGameButton_Clicked(Event event) {
        //m_newGameButton.disable();
	    m_hitButton.enable();
	    m_StayButton.enable();
		m_deckCanvas.newGame();
	}

	public void init() {
		super.init();

		//{{INIT_CONTROLS
		setLayout(null);
		addNotify();
		resize(409,281);
		setFont(new Font("Dialog", Font.BOLD, 12));
		setBackground(new Color(32832));
		m_newGameButton = new java.awt.Button("New Game");
		m_newGameButton.reshape(300,24,84,24);
		add(m_newGameButton);
		m_newGameButton.disable();
		m_hitButton = new java.awt.Button("Hit");
		m_hitButton.reshape(300,72,84,24);
		add(m_hitButton);
		m_hitButton.disable();
		m_StayButton = new java.awt.Button("Stay");
		m_StayButton.reshape(300,120,84,24);
		add(m_StayButton);
		m_StayButton.disable();
		m_labelIntro = new java.awt.Label("Loading images ...",Label.CENTER);
		m_labelIntro.reshape(12,120,264,24);
		m_labelIntro.setFont(new Font("Dialog", Font.BOLD, 14));
		m_labelIntro.setForeground(new Color(16776960));
		add(m_labelIntro);
		m_deckCanvas = new Deck(this);
		m_deckCanvas.hide();
		m_deckCanvas.reshape(12,12,277,240);
		add(m_deckCanvas);
		labelAddress = new java.awt.Label("adrian.dorache@codecentrix.com");
		labelAddress.reshape(12,264,314,15);
		add(labelAddress);
		//}}

		m_mediaTracker = new MediaTracker( this );
		m_cardsImage  = getImage(getCodeBase(), "AllCards.gif");
		m_mediaTracker.addImage(m_cardsImage, 0);
	}

	public boolean handleEvent(Event event) {
		if (event.target == m_newGameButton && event.id == Event.ACTION_EVENT) {
			mNewGameButton_Clicked(event);
			return true;
		}
		if (event.target == m_hitButton && event.id == Event.ACTION_EVENT) {
			mHitButton_Clicked(event);
			return true;
		}
		if (event.target == m_StayButton && event.id == Event.ACTION_EVENT) {
			mStayButton_Clicked(event);
			return true;
		}
		return super.handleEvent(event);
	}
	
	public void start() {
   	    m_imageLoaderThread = new Thread(this);
        m_imageLoaderThread.start();
    }

    public void stop() {
        m_imageLoaderThread.stop();
        m_imageLoaderThread = null;
    }

    public void run() {
        try {
            m_mediaTracker.waitForID(0);
        }
        catch (InterruptedException e) {
            return;
        }
        repaint();
    }

	public void paint(Graphics g) {
        Font        font = getFont();
        FontMetrics fm = g.getFontMetrics(font);
        String  str = "";

        if(m_bLoadingComplete == false) {
            if ((m_mediaTracker.statusID(0, true) & MediaTracker.ERRORED) != 0) {
                str = new String("Error occured during image loading ...");
                m_bLoadingComplete = true;
            }
            else
                if ((m_mediaTracker.statusID(0, true) & MediaTracker.COMPLETE) != 0) {
                    //the images are completely loaded
                    remove(m_labelIntro);
                    m_bLoadingComplete = true;
                    m_newGameButton.enable();
                    //m_hitButton.enable();
                    Card.initCards( m_cardsImage, m_deckCanvas );
                    m_deckCanvas.show();

                    /*Card      card = new Card( 0, CardType.HEARTS );
                    card.drawCard( g, 0, 0 );*/
                    //////////////////////////////////////////////////////////////////
                }
                else str = new String("Loading images ...");
            m_labelIntro.setText( str );
        }
    }
    
	//{{DECLARE_CONTROLS
	java.awt.Button m_newGameButton;
	java.awt.Button m_hitButton;
	java.awt.Button m_StayButton;
	java.awt.Label  m_labelIntro;
	java.awt.Label  labelAddress;
	//}}
	
	private Deck                m_deckCanvas;
	private	MediaTracker        m_mediaTracker;
	private Thread              m_imageLoaderThread;
	private Image               m_cardsImage;
    private boolean             m_bLoadingComplete = false;
}
