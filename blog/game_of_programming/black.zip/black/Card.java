import java.awt.*;
import java.awt.image.*;

public class Card
{
    public Card( int nValue, int type )
    {
        m_nCardValue = nValue;
        m_nCardType   = type;
    }

    public void drawCard( Graphics g, int x, int y )
    {
        int         nValue = ((m_nCardValue > 10 )? (m_nCardValue - 14):(m_nCardValue - 13 ));
        Graphics    subarea = g.create( x, y, m_widthOneCard, m_heightOneCard );

        if( m_nCardValue != 0 ) //back card
            subarea.drawImage( m_cardsImage , - m_nCardType * m_widthOneCard ,
                                   nValue  * m_heightOneCard, m_imgObs );
        else
        {
            Color       currentColor = subarea.getColor();
            subarea.setColor(Color.blue);
            subarea.fillRoundRect( 3, 3, m_widthOneCard - 6, m_heightOneCard - 6, m_widthOneCard / 6, m_widthOneCard / 6 );
            subarea.setColor( currentColor );
        }

        subarea.dispose();
    }

    public static Dimension getCardSize()
    {
        return new Dimension( m_widthOneCard, m_heightOneCard );
    }

    public static void initCards( Image cardsImage, ImageObserver imgObs )
    {
        m_cardsImage = cardsImage;
        m_imgObs     = imgObs;
        
        m_CardsWidth  = m_cardsImage.getWidth( m_imgObs );
        m_CardsHeight = m_cardsImage.getHeight( m_imgObs );
        
        m_heightOneCard = m_CardsHeight / 13;
        m_widthOneCard  = m_CardsWidth  / 4;
    }

    public int getValue()
    {
        if(m_nCardValue == 1)
            return m_nCardValue + 10; // ace is 11
        if(m_nCardValue > 10)
            return 10; //every card greater than 10 worth 10 points
        return m_nCardValue; //anything else worth what it shows
    }

    public int getCard(){
        return m_nCardValue;
    }
    
    public int getCardType(){
        return m_nCardType;
    }
    
    ////////////////////////////////////////////////////
           private int           m_nCardValue;
           private int           m_nCardType;
    static private Image         m_cardsImage;
	static private ImageObserver m_imgObs;
	static private int           m_CardsWidth;
	static private int           m_CardsHeight;
    static private int           m_heightOneCard;
    static private int           m_widthOneCard;
} 