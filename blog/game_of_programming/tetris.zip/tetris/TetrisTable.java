import java.awt.*;
import java.util.Random;

 public final class TetrisTable
 {
    //################################################################
    public  TetrisTable(){
        table = new Cell[ length + 1 ][ width + 2 ];    
        for( int i = 0; i < length + 1; ++i )
            for( int j = 0; j < width + 2; ++j )       
                table[ i ][ j ] = new Cell( (byte)0, Color.white );
        initCells();
        
        randomNo = new Random();
        generate();
    }

    //################################################################
    public boolean dropObj(){
        if( gameOver == true )
            return true;
        while( validMove( (byte)( x + 1 ), y ) )
            x++;
        return true;
    }
    
    //################################################################
    public boolean moveLeft(){
        if( gameOver == true )
            return true;
        if( validMove( x, (byte)(y - 1) ) == true ){
            --y;
            return true;
        }
        return false;
    }
    
    //################################################################
    public boolean moveRight(){
        if( gameOver == true )
            return true;
        if( validMove( x, (byte)(y + 1) ) == true ){
            ++y;
            return true;
        }
        return false;
    }
    
    //################################################################
    public boolean avans(){
        if( gameOver == true)
            return true;
        if( validMove( (byte)(x + 1), y ) == true ){
            ++x;
        }
        else{
            insertObjInTable();
            removeLines();
            generate();
        }
        return true;
    }

    //################################################################
    public boolean rotate(){
        boolean     test = true;
        
        byte x1 = x, y1 = y;
        
        x += objCurent.getCx();     //corections
        y += objCurent.getCy();
        
        DropObj     newObj = objCurent.duplicate();     //make a copy of the object
        objCurent.rotate();         //rotation
        
        x -= objCurent.getCx();     //corections
        y -= objCurent.getCy();
        
        if( !validMove( x, y ) ){
            objCurent = newObj;
            x = x1; y = y1;
            test = false;
        }
        return test;
    }
    
    //################################################################
    public void draw( Graphics g ){
        for( int i = 0; i < length + 1; ++i )
            for( int j = 0; j < width + 2; ++j ){
                    g.setColor( table[ i ][ j ].color );
                    g.fillRect( j * dimension, i * dimension, dimension, dimension );
                    if( table[ i ][ j ].info == 1 ){
                        g.setColor( Color.black );
                        g.drawRect( j * dimension, i * dimension, dimension - 1, dimension - 1);
                    }
            }
        objCurent.draw( g, x, y, dimension );
        if( gameOver == true ){
            String  text = " G A M E  O V E R ";
            int     textWidth = g.getFontMetrics().stringWidth( text );
            int     textHeight = g.getFontMetrics().getHeight();

            g.setColor( Color.black );
            g.fillRect( ( dimension * ( width + 2 ) - textWidth )/ 2,
                        ( dimension * ( length - 1 ) - textHeight ) / 2, textWidth, textHeight + textHeight / 2  );
            g.setColor( Color.yellow );
            g.drawString( text, ( dimension * ( width + 2 ) - textWidth ) / 2,
                                                        ( dimension * length ) / 2  );            
        }
    }

    //################################################################
    private boolean validMove( byte x, byte y ){
        for( int i = 0; i < objCurent.getLength(); ++i )
            for( int j = 0; j < objCurent.getWidth(); ++j ){
                if( x + i >= 0 && x + i <= length ) 
                    if( objCurent.getAt( i, j ) == 1 && table[ x + i ][ y + j ].info == 1 )
                        return false;
            }
        return true;
    }
    
    //################################################################
    private void    generate(){         //generate a new object
        int     aux = randomNo.nextInt();
        if( aux < 0 )
            aux *= -1;
            
        aux %= noOfObj;
        
        switch( aux ){
            case    0:
                objCurent = new LineShape();
                break;
            case    1:
                objCurent = new SquareShape();
                break;
            case    2:
                objCurent = new TShape();
                break;
            case    3:
                objCurent = new CornerShape();
                break;
            case    4:
                objCurent = new CornerShape2();
                break;
            case    5:
                objCurent = new ZShape();
                break;
            case    6:
                objCurent = new ZShape2();
                break;
        }
        aux = randomNo.nextInt();                 
                    
        if( aux < 0 )
            objCurent.rotate();     //random rotation
                    
        x = 0; y = (byte)( width / 2 );
        x -= objCurent.getCx();     //corections
        y -= objCurent.getCy();
        
        if( x < 0 )     //for the case a vertical line is generated
            x = 0;
            
        if( validMove( x, y ) == false )
                gameOver = true;   // in this case the game is over
    }

    //################################################################
    private void initCells(){
        for( int i = 0; i < length + 1; ++i ){
            (table[ i ][ 0 ]).color = (table[ i ][ width + 1 ]).color = Color.black;
            (table[ i ][ 0 ]).info = (table[ i ][ width + 1 ]).info = (byte)1;
        }
        for( int j = 0; j < width + 2; ++j ){
            (table[ length ][ j ]).color = Color.black;
            (table[ length ][ j ]).info = (byte)1;
        }
    }

    //################################################################
    public void insertObjInTable(){
        for( int i = x; i < x + objCurent.getLength(); ++i )
            for( int j = y; j < y + objCurent.getWidth(); ++j )
                if( objCurent.getAt( i - x, j - y ) == 1 ){
                    table[ i ][ j ].info = 1;   
                    table[ i ][ j ].color = objCurent.getColor();
                }
    }
    
    //################################################################
    public void removeLines(){       //true if for redrawing
        boolean flag = false;
        
        for( int i =  x; i < x + objCurent.getLength(); ++i ){
            boolean test = true;           //test if the line i is completed
            for( int j = 1; j < width + 1; ++j ){
                if( table[ i ][ j ].info == 0 ){
                    test = false;
                    break;
                }
            }
            if( test == true ){     //remove the completed line and move down the other lines 
                for( int j = i; j > 0; --j )
                    for( int k = 1; k < width + 1; ++k ){
                        table[ j ][ k ].info = table[ j - 1 ][ k ].info;
                        table[ j ][ k ].color = table[ j - 1 ][ k ].color;
                    }
                ++lines;
            }
        }
    }
    
    public void setDim( byte dim ){
        dimension = dim;
    }
    
    public byte getDim(){
        return dimension;
    }
    
    public byte getWidth(){
        return  width;
    }
    
    public byte getLength(){
        return  length;
    }
    
    public int  getLines(){
        return  lines;
    }

    private Thread      timer;
    private boolean     gameOver = false;
    
    private int         lines = 0;
    private DropObj     objCurent;           //the current droping object
    private Cell[][]    table;              
    private byte        x, y;                //the logical coordinates of the current object
    private byte        dimension;           //dimensiunea patratelului
    
    private Random      randomNo;            //used for the random number generation
    
    final private byte  width  = 12;         //the width of the table
    final private byte  length = 20;         //the length of the table
    final private byte  noOfObj = 7;         //the number of the objects
}
