import java.awt.*;

public class Cell
{
    public Cell( byte info_, Color color_ ){
        info = info_;
        color = color_;
    }
    public  byte    info;
    public Color    color;
}

