import java.awt.*;
import DropObj;

public final class TShape extends DropObj
{
    public TShape(){
        super( (byte)2, (byte)3 );
        color = Color.green;
        datas[ 0 ][ 0 ] = datas[ 0 ][ 1 ]= datas[ 0 ][ 2 ] = datas[ 1 ][ 1 ] = 1;
        datas[ 1 ][ 0 ] = datas[ 1 ][ 2 ] = 0;
        
        cx = 0; cy = 0;
    }
}

