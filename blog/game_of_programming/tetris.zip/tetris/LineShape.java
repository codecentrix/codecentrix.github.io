import java.awt.*;

public final class LineShape extends DropObj
{
    public LineShape(){
        super( (byte)1, (byte)4 );
        color = Color.red;
        datas[ 0 ][ 0 ] = datas[ 0 ][ 1 ]= datas[ 0 ][ 2 ] = datas[ 0 ][ 3 ] = 1;
        
        cx = 0; cy = 1;
    }
}

