import java.awt.*;
import DropObj;

public final class SquareShape extends DropObj
{
     public SquareShape(){
        super( (byte)2, (byte)2 );
        color = Color.blue;
        datas[ 0 ][ 0 ]=datas[ 0 ][ 1 ]= datas[ 1 ][ 0 ] = datas[ 1 ][ 1 ] = 1;
        
        cx = cy = 0;
    }
    
    public void rotate(){
    }
}

