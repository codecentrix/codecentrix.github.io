import java.awt.*;

public class IntroCanvas extends Canvas
{
    public synchronized void avans(){
        repaint();
    }

    public synchronized void update( Graphics g){
        //override the update method so the background won't be erased
        paint( g );
    }

    public synchronized void paint( Graphics g ){
        offscreenGraphics.clearRect(0, 0, size().width, size().height);
	    g.drawImage(offscreenImage, 0, 0, this);
    }

    public void init(){
        offscreenImage = createImage(size().width, size().height);
		offscreenGraphics = offscreenImage.getGraphics();
    }

    private Image       offscreenImage;
    private Graphics    offscreenGraphics;
}
