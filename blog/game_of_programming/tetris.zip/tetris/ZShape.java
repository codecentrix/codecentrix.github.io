import java.awt.*;

public final class ZShape extends DropObj
{
    public ZShape(){
        super( (byte)2, (byte)3 );
        color = Color.orange;
        datas[ 0 ][ 0 ] = datas[ 0 ][ 1 ]= datas[ 1 ][ 1 ] = datas[ 1 ][ 2 ] = 1;
        datas[ 1 ][ 0 ] = datas[ 0 ][ 2 ] = 0;
        
        cx = 0; cy = 0;
    }
}

