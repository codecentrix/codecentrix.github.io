import java.awt.*;

public class DropObj
{
    //##########################################################
    public DropObj( byte m, byte n ){
        length = m;
        width = n;
        datas = new byte [ length ][ width ];
    }

    //##########################################################
    public  void rotate(){
        byte[][]    auxDatas = new byte[ width ][ length ];
        
        for( int i = 0; i < length; ++i )
            for( int j = 0; j < width; ++j ){
                auxDatas[ j ][ i ] = datas[ i ][ j ];
            }
        
        byte    l = width;
        width = length;
        length = l;
            
        for( int i = 0; i < length; ++i )
            for( int j = 0; j < width / 2; ++j ){
                byte aux = auxDatas[ i ][ width - j - 1 ];
                auxDatas[ i ][ width - j - 1 ]= auxDatas[ i ][ j ];
                auxDatas[ i ][ j ] = aux;
            }
            
        datas = auxDatas;
        
        l = cx;
        cx = cy;
        cy = l;
    }
    
    //##########################################################
    public DropObj duplicate(){     //make a copy of the object
        DropObj     newObj = new DropObj( length, width );
        newObj.cx = cx;
        newObj.cy = cy;
        newObj.color = color;
        
        for( int i = 0; i < length; ++i )
            for( int j = 0; j < width; ++j ){
                newObj.datas[ i ][ j ] = datas[ i ][ j ];
            }
        return newObj;
    }

    //##########################################################
    //the coordinates for draw are logical coordinates
    public  void draw(Graphics g, int x, int y, int dimension ){ //draw the object at x, y
        for( int i = 0; i < length; ++i )
            for( int j = 0; j < width; ++j ){
                if( datas[ i ][ j ] == 1 ){
                    g.setColor( color );
                    g.fillRect( ( y + j ) * dimension, ( x + i ) * dimension, dimension, dimension );
                    g.setColor( Color.black );
                    g.drawRect( ( y + j ) * dimension, ( x + i ) * dimension, dimension - 1, dimension - 1 );
                }
            }
    }

    public  byte getCx(){
        return cx;
    }
    
    public  byte getCy(){
        return cy;
    }
    
    public  byte getLength(){
        return length;
    }
    
    public  byte getWidth(){
        return width;
    }
    
    public  byte getAt( int i, int j ){
        return datas[ i ][ j ];
    }
    
    public Color getColor(){
        return color;
    }
    
    protected byte        cx, cy;           //the coordinates of the center of the object relative to top left
    protected Color       color;            //the color of the object
    protected byte[][]    datas;            //the shape of the object
    private   byte        width, length;    //the dimension of the object
}
