import java.awt.*;

public final class My_Canvas extends Canvas
{   
    //##################################################
	public synchronized void MyCanvas_keyDown( int key ) {
	    boolean     test = false;
        switch( key ){
            case    Event.UP:
                test = tetris.rotate();
                break;
            case    Event.LEFT:
                test = tetris.moveLeft();
                break;
            case    Event.RIGHT:
                test = tetris.moveRight();
                break;
            case    Event.DOWN:
                test = tetris.dropObj();
                break;
        }
        if( test == true )
    		repaint();
	}
    
    public synchronized void avans(){
        tetris.avans();
        repaint();
    }
    
    public My_Canvas(){
        tetris = new TetrisTable();
    }

    public synchronized void update( Graphics g){
        //override the update method. this way the background is not erased
        paint( g );
    }

    public synchronized void paint( Graphics g ){
        offscreenGraphics.clearRect(0, 0, size().width, size().height);
	    tetris.draw( offscreenGraphics );
	    g.drawImage(offscreenImage, 0, 0, this);
    }
    
    public void init(){

        Dimension       dimension = size();       //the dimension of the canvas
        byte            mp     = (byte)( dimension.width / ( tetris.getWidth() + 2 ) );
        int             width  = mp * ( tetris.getWidth() + 2 );
        int             height = mp * ( tetris.getLength() + 1 );
        
        resize( width, height );        
        tetris.setDim( mp );
        
        offscreenImage = createImage(size().width, size().height);
		offscreenGraphics = offscreenImage.getGraphics();
    }

    public  int getLines(){
        return tetris.getLines();
    }
    
    public int getSpeed(){
        return speed;
    }
    
    public void newGame(){
        tetris = new TetrisTable();
        init();
    }

    private TetrisTable         tetris;
    private int                 speed = 500;
    private Image       offscreenImage;
    private Graphics    offscreenGraphics;
}
