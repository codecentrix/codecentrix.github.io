import java.awt.*;

public final class CornerShape2 extends DropObj
{
    public CornerShape2(){
        super( (byte)2, (byte)3 );
        color = Color.cyan;
        datas[ 0 ][ 0 ] = datas[ 0 ][ 1 ]= datas[ 0 ][ 2 ] = datas[ 1 ][ 2 ] = 1;
        datas[ 1 ][ 1 ] = datas[ 1 ][ 0 ] = 0;
        
        cx = 0; cy = 0;
        
    }
}

