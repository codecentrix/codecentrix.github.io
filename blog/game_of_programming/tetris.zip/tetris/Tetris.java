import java.awt.*;
import java.applet.*;

public class Tetris extends Applet
                    implements Runnable{

	void button2_Clicked(Event event) {
   	    gameIsStarted = false;
	    button1.enable();
	    button2.disable();
	    canvas1.newGame();
	    requestFocus();
        canvas1.hide();
        introCanvas.show();
	}

	public boolean handleEvent(Event event) {
		if (event.target == button1 && event.id == Event.ACTION_EVENT) {
			button1_Clicked(event);
			return true;
		}
		if (event.target == button2 && event.id == Event.ACTION_EVENT) {
			button2_Clicked(event);
			return true;
		}
		return super.handleEvent(event);
	}

	void button1_Clicked(Event event) {
	    button1.disable();
	    button2.enable();
	    requestFocus();
  	    canvas1.show();
  	    introCanvas.hide();
   	    gameIsStarted = true;
	}

	public void init() {
		super.init();
		//{{INIT_CONTROLS
		setLayout(null);
		addNotify();
		resize(301,294);
		setBackground(new Color(13026427));
		label1 = new java.awt.Label("adrian.dorache@codecentrix.com");
		label1.reshape(12,276,264,12);
		label1.setFont(new Font("Dialog", Font.BOLD, 12));
		add(label1);
		label2 = new java.awt.Label("0");
		label2.reshape(216,36,48,21);
		label2.setFont(new Font("Dialog", Font.BOLD, 14));
		add(label2);
		label3 = new java.awt.Label("Lines:");
		label3.reshape(216,12,50,15);
		add(label3);
		button1 = new java.awt.Button("Start game");
		button1.reshape(216,60,75,26);
		add(button1);
		button2 = new java.awt.Button("Quit game");
		button2.reshape(216,96,75,26);
		add(button2);
		//}}

        button2.disable();
        canvas1 = new My_Canvas();
        canvas1.reshape(12,12,181,325);
		canvas1.setBackground(new Color(16777215));
		add(canvas1);
		canvas1.init();
		canvas1.hide();

        introCanvas = new IntroCanvas();
        introCanvas.reshape(12,12,181,260);
		introCanvas.setBackground(new Color(0));
		add(introCanvas);
		introCanvas.init();
	}

	public boolean keyDown(Event event, int key ) {
	    canvas1.MyCanvas_keyDown( key );
	    return true;
	}

	public void run(){
	    while( true ){
      	    if( gameIsStarted == true ){
        	    canvas1.avans();
        	    if( oldLines != canvas1.getLines() ){
        	        oldLines = canvas1.getLines();
        	        label2.setText( String.valueOf( oldLines ) );
        	    }
    	    }
    	    else
    	        introCanvas.avans();

	        try{
	            if( gameIsStarted == true )
    	            timer.sleep( canvas1.getSpeed() - 10 * oldLines );
    	        else
    	            timer.sleep( 100 );
	        }
	        catch (InterruptedException e)
	        {
	        }
	    }
	}

	public void start(){
	    if( timer == null ){
    	    timer = new Thread( this );
	        timer.start();
	    }
	}

	public void stop(){
	    if( timer != null ){
    	    timer.stop();
    	    timer = null;
    	}
	}

	My_Canvas       canvas1;
	IntroCanvas     introCanvas;
	int             oldLines = 0;
	Thread          timer = null;
	boolean         gameIsStarted = false;

	//{{DECLARE_CONTROLS
	java.awt.Label label1;
	java.awt.Label label2;
	java.awt.Label label3;
	java.awt.Button button1;
	java.awt.Button button2;
	//}}
}