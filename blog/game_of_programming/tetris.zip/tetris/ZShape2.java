import java.awt.*;

public final class ZShape2 extends DropObj
{
    public ZShape2(){
        super( (byte)2, (byte)3 );
        color = Color.yellow;
        datas[ 0 ][ 2 ] = datas[ 0 ][ 1 ]= datas[ 1 ][ 1 ] = datas[ 1 ][ 0 ] = 1;
        datas[ 1 ][ 2 ] = datas[ 0 ][ 0 ] = 0;
        
        cx = 0; cy = 0;
        
    }
}

