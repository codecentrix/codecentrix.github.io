/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////

#pragma once
#include "resource.h"       // main symbols

#include "ClipboardHelper_i.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Single-threaded COM objects are not properly supported on Windows CE platform, such as the Windows Mobile platforms that do not include full DCOM support. Define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA to force ATL to support creating single-thread COM object's and allow use of it's single-threaded COM object implementations. The threading model in your rgs file was set to 'Free' as that is the only threading model supported in non DCOM Windows CE platforms."
#endif



// CClipBoard

class ATL_NO_VTABLE CClipBoard :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CClipBoard, &CLSID_ClipBoard>,
	public IDispatchImpl<IClipBoard, &IID_IClipBoard, &LIBID_ClipboardHelperLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CClipBoard()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CLIPBOARD)


BEGIN_COM_MAP(CClipBoard)
	COM_INTERFACE_ENTRY(IClipBoard)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:

	STDMETHOD(GetClipboardText)(BSTR* pBstrClipboardText);
	STDMETHOD(SetClipboardText)(BSTR bstrClipboardText);

private:
	BOOL    SetTextInClipboard(LPCSTR szText);
	BOOL    SetTextInClipboard(LPCWSTR szText);
	HRESULT ClearClipboard();
};

OBJECT_ENTRY_AUTO(__uuidof(ClipBoard), CClipBoard)
